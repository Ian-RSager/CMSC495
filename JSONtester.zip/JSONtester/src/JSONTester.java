import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class JSONTester {
	
	

	public static void main(String[] args) {
		
		// Open JSON file
		String fileName = "spells.json";
		String line = null;
		String jsonString = "";
		
		try {
            FileReader fileReader = 
                new FileReader(fileName);

            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                jsonString += line;
            }   

            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
        }
		
		// Parse JSON file
		Gson gson = new Gson();
		Spell[] spellArray = gson.fromJson(jsonString, Spell[].class);
		
		// Add data to hashmap
		HashMap<String, Spell> spellMap = new HashMap<>();
		for (Spell spell: spellArray) {
			spellMap.put(spell.name, spell);
		}
		
		// Menu
		Scanner sc = new Scanner(System.in);
		
		System.out.println("1 - search for spell by list location");
		System.out.println("2 - search for spell by name");
		System.out.println("3 - Exit");
		System.out.print("Enter your choice: ");
		int number = sc.nextInt();
		
		switch(number) {
		case 1:
			System.out.print("Enter list location: ");
			int location = sc.nextInt();
			spellArray[location].printData();
			break;
		case 2:
			System.out.print("Enter spell name: ");
			String spellName = sc.next();
			spellMap.get(spellName).printData();
			break;
		case 3:
			sc.close();
			System.exit(0);
		}
	}

}
