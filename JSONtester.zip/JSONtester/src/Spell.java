import java.util.Map;

public class Spell {
	String casting_time;
	String[] classes;
	Map<String, Object> components;
	String description;
	String duration;
	String level;
	String name;
	String range;
	Boolean ritual;
	String school;
	String[] tags;
	String type;
	
	public Spell(String casting_time, String[] classes, Map<String, Object> components, String description,
			String duration, String level, String name, String range, Boolean ritual, String school,
			String[] tags, String type) {
		this.casting_time = casting_time;
		this.classes = classes;
		this.components = components;
		this.description = description;
		this.duration = duration;
		this.level = level;
		this.name = name;
		this.range = range;
		this.ritual = ritual;
		this.school = school;
		this.tags = tags;
		this.type = type;
	}
	
	public void printData() {
		System.out.println("\nName: " + name);
		System.out.println("\nCasting time: " + casting_time);
		System.out.println("Classes:");
		for (String eachClass: classes) {
			System.out.println("\t" + eachClass);
		}
		System.out.println("Components:");
		for (Map.Entry<String, Object> entry : components.entrySet()) {
			System.out.println("\t" + entry.getKey() + ": " + entry.getValue().toString());
		}
		System.out.println("Description: " + description);
		System.out.println("Duration: " + duration);
		System.out.println("Level: " + level);
		System.out.println("Range: " + range);
		System.out.println("Ritual: " + ritual.toString());
		System.out.println("School: " + school);
		System.out.println("Tags:");
		for (String eachTag: tags) {
			System.out.println("\t" + eachTag);
		}
		System.out.println("Type: " + type);		
	}
}


